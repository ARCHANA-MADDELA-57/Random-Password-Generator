from django.apps import AppConfig


class RandompassappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'randompassapp'
